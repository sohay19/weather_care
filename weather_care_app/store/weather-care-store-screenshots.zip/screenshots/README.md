# 스토어 스크린샷

## 결과물

- iOS: `ios/` — 1320×2868 px, RGB PNG, 5장
- Android: `android/` — 1080×1920 px, RGB PNG, 5장
- 미리보기: `preview-ios.png`, `preview-android.png`
- 실제 앱 캡처 원본: `source/`

노출 순서는 핵심 화면을 먼저 보여주도록 `Main → Today → Detail → Week → Setting`으로 구성했다.

## 홍보 문구

1. Main — `오늘 챙길 것만 / 한눈에`
2. Today — `시간대별 날씨를 / 하루 흐름으로`
3. Detail — `판단 근거까지 / 자세히`
4. Week — `일주일 계획을 / 미리 가볍게`
5. Setting — `내 위치와 알림을 / 내 생활에 맞게`

## 제작 기준

- 배경은 앱 아이콘 계열의 단색 `#4C77A4`를 사용했다.
- 앱 화면은 Android 에뮬레이터에서 release 빌드를 직접 캡처했다.
- 생성형 이미지로 UI나 한글을 재현하지 않고 실제 화면을 그대로 사용했다.
- PNG는 투명도 없는 RGB로 저장했다.

다시 생성하려면 `python store/generate_store_screenshots.py`를 실행한다.
